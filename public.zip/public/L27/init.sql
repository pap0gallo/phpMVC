CREATE TABLE IF NOT EXISTS products (
                                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                                        title VARCHAR(255) NOT NULL,
    price INTEGER
    );
